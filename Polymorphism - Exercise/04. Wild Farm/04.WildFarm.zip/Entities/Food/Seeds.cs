﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04._Wild_Farm.Entities.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {

        }
    }
}

﻿namespace CommandPattern.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl.Models
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}

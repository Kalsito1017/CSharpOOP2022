﻿namespace FoodShortage.Models.Interfaces
{
    public interface IIdentifiable
    {
        string Name { get; }
        int Age { get; }
    }
}
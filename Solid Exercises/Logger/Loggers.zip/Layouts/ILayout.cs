﻿
namespace Logger.ILogger
{
    public interface ILayout
    {
        string Format { get; }
    }
}
